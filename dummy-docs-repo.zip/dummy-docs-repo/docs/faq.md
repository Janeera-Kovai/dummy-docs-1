# FAQ

## Can I invite team members?

Yes. Go to **Settings > Team** and select **Invite**.
