# API overview

Use the REST API to manage articles programmatically.

Base URL: `https://api.example.com/v1`
