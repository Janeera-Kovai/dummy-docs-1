# Getting started

Create your first project in a few steps.

1. Sign in to the portal.
2. Select **New project**.
3. Enter a project name and select **Create**.
