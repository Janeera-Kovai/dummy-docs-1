#!/usr/bin/env bash
# Print word counts for every Markdown file in docs/
wc -w docs/*.md
